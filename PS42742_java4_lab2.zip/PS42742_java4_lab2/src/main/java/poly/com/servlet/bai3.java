package poly.com.servlet;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class bai3 {
	public static void main(String[] args)
	{
		// 
		//create();
		//delete();
		//findAll();
		findFplRole(null, false);
		
		
	}
	
	private static void findFplRole(String search, boolean role) {
		// nap 
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "SELECT o FROM User o WHERE	o.Email	LIKE :search	AND	o.Admin=:role	";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("search", "%fpl.edu.vn");
			query.setParameter("role", role);
			// Truy vÃ¡ÂºÂ¥n
			List<User> list = query.getResultList();

			// HiÃ¡Â»Æ’n thÃ¡Â»â€¹ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy van thanh cong!");
		} catch (Exception e) {
			System.out.println("Truy van loi!");
		}
		em.close();
		emf.close();
	}

}
