package Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet({"/crud/create", "/crud/update", "/crud/delete", "/crud/edit/*"})
public class bai1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bai1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8"); 
		response.setContentType("text/html; charset=UTF-8");

		String uri = request.getRequestURI();
		   
		    
		      if(uri.contains("/create")) {
		    	 response.getWriter().println("them");
		     } if(uri.contains("/update")) {
		    	 response.getWriter().println("Đây là update");
		     } if(uri.contains("/delete")) {
		    	 response.getWriter().println("<h1> Đây là xóa </h1>");
		     } else if(uri.contains("/edit/*")) {
		    	 response.getWriter().println("Đây là edit");
		     }
	//	     request.setAttribute("page", page);
	//	     request.getRequestDispatcher("/views/crud.jsp").forward(request, response);

			}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
