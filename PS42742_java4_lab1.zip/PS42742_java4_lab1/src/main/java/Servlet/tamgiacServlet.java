package Servlet;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet({"/tam-giac", "/dien-tich", "/chu-vi"})
public class tamgiacServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public tamgiacServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/views/tamgiac.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double a = Double.parseDouble(request.getParameter("a"));
		double b = Double.parseDouble(request.getParameter("b"));
		double c = Double.parseDouble(request.getParameter("c"));
		
		// đọc b và c ở đây
		if( (a + b > c) && (a + c > b) && (b + c > a) ) {
			double chuVi = (a + b + c);
			String uri = request.getRequestURI();
			if(uri.contains("dien-tich")) { // [Tính diện tích].Click
				double dienTich = Math.sqrt(chuVi * (a + b - c) * (a + c - b) * (b + c - a))/4;
				request.setAttribute("message", "Diện tích của tam giác là " + dienTich);
			}
			else{ // [Tính chu vi].Click
				request.setAttribute("message", "Chu vi của tam giác là " + chuVi);
			}
		}
		else {
			request.setAttribute("message", "Không thỏa mãn các cạnh của một tam giác!");
		}

		request.getRequestDispatcher("/views/tamgiac.jsp").forward(request, response);
	}
}


