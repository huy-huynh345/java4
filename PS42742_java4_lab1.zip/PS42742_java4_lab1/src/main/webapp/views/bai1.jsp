<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="menu.jsp"></jsp:include>

   <h2>Chọn chức năng CRUD</h2>

    <form action="${pageContext.request.contextPath}/crud/create" method="get">
        <button type="submit">Create</button>
    </form>

    <form action="${pageContext.request.contextPath}/crud/update" method="get">
        <button type="submit">Update</button>
    </form>

    <form action="${pageContext.request.contextPath}/crud/delete" method="get">
        <button type="submit">Delete</button>
    </form>

    <form action="${pageContext.request.contextPath}/crud/edit/2024" method="get">
        <button type="submit">Edit (2024)</button>
    </form>
</body>
</html>