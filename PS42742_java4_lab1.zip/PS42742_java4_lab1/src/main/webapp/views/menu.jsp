<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
 <a href="/java4_Lab1_bai2/views/bai1.jsp"> bai1 </a>
 <a href="/java4_Lab1_bai2/views/tamgiac.jsp"> bai2 </a>
 <a href="/java4_Lab1_bai2/views/dangky.jsp"> bai3 </a>


</body>
</html>