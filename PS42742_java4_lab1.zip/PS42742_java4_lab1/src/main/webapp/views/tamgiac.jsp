<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<form action="/tam-giac" method="post">
		<input name="a" placeholder="Cạnh a?"><br>
		<input name="b" placeholder="Cạnh b?"><br>
		<input name="c" placeholder="Cạnh c?"><hr>
		<button formaction="${pageContext.request.contextPath}/dien-tich">Tính diện tích</button>
		<button formaction="/java4_Lab1_bai2/chu-vi">Tính chu vi</button>
	</form>
	<h3>${message}</h3>

</body>
</html>